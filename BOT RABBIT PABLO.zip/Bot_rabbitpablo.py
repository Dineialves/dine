import time
import telebot
from datetime import datetime
from telebot.types import InputFile, InlineKeyboardButton, InlineKeyboardMarkup
import random
import pytz


api_key = ' ' # COLOQUE O API, TOKEN DO BOT CRIADO PELO BotFather
chat_id = ' ' # COLOQUE O CHAT ID DO CANAL, PEGUE O ID NESSE BOT Get My ID

bot = telebot.TeleBot(token=api_key)

# Definindo a variável bd
bd = {
    'message_ids1': None,
    'message_delete1': False
}

def ALERT_GALE1(link_cadastro, num_jogadas):
    h = datetime.now().hour
    m = datetime.now().minute + 1
    s = datetime.now().second
    if h <= 9:
        h = f'0{h}'
    if m <= 9:
        m = f'0{m}'
    if s <= 9:
        s = f'0{s}'
    message_id = bot.send_message(
        chat_id=chat_id, text=f'''𝗛𝗔𝗖𝗞𝗘𝗔𝗡𝗗𝗢 𝗡𝗢𝗩𝗢 𝗛𝗢𝗥𝗔́𝗥𝗜𝗢🧧🔥
''', parse_mode='Markdown').message_id
    bd['message_ids1'] = message_id

def DELETE_GALE1():
    if bd['message_delete1'] == True:
        bot.delete_message(chat_id=chat_id, message_id=bd['message_ids1'])
        bd['message_delete1'] = False

while True:
    for i in range(25):
        link_cadastro = "   " #COLOQUE O LINK DA PLATAFORMA DENTRO DO "*"

        sp_timezone = pytz.timezone('America/Sao_Paulo')
        current_time_sp = datetime.now(sp_timezone)
        h = current_time_sp.hour
        m = current_time_sp.minute + 4
        s = current_time_sp.second
        if h <= 9:
            h = f'0{h}'
        if m <= 9:
            m = f'0{m}'
        if s <= 9:
            s = f'0{s}'
        print(f'{h}:{m}:{s}')
    
    for i in range(25):


       


        print

        def button_link():

            markup = InlineKeyboardMarkup()

            markup.row_width = 2

            markup.add(InlineKeyboardButton(text=F"𝗖𝗟𝗜𝗤𝗨𝗘 𝗔𝗤𝗨𝗜 𝗡𝗢 𝗝𝗢𝗚𝗢 💸", url="  ")) #COLOQUE O LINK DA PLATAFORMA DENTRO DO "*"
            return markup

        num_jogadas = random.randint(3, 19)
        num_turbo = random.randint(3, 12)
        num_valor = random.choice([60, 96])
        win_fortune = random.choice(['𝗚𝗔𝗡𝗛𝗔𝗠𝗢𝗦 𝗗𝗘 𝗡𝗢𝗩𝗢!🔥','𝗙𝗔𝗭 𝟭𝟬𝗞 𝗘 𝗗𝗢𝗥𝗠𝗜𝗥!🎰', '𝗗𝗘𝗣𝗢́𝗦𝗜𝗧𝗘 𝗘 𝗩𝗘𝗠 𝗖𝗢𝗠 𝗡𝗢́𝗦!🤴🔥', '𝗠𝗔𝗦 𝗨𝗠 𝗦𝗜𝗡𝗔𝗟 𝗖𝗘𝗥𝗧𝗘𝗜𝗥𝗢!🔥'])
        opo_fortune = random.choice(['🤑 JOGUE AGORA! 💸'])

        # Texto que você deseja enviar junto com a imagem
        texto = f'''
{opo_fortune}

🐰 Fortune rabbit
🔥 {num_jogadas}x Normal
⚡️ {num_turbo}x Turbo
🎯  ACERTIVIDADE: {num_valor}%
⏰ Validade: 5 minutos

🚨 FUNCIONA APENAS NA PLATAFORMA ABAIXO! ⬇️

🎰 CADASTRO NA PLATAFORMA:

🎰 ENTRE NO JOGO AGORA:

⚠️ NÃO TENTE EM OUTRO SITE! ⚠️
        '''
        nome_da_imagem = 'RABBIT.jpg'
        button_markup = button_link()
        with open(nome_da_imagem, 'rb') as img:
            bot.send_photo(chat_id=chat_id, photo=img, caption=texto, reply_markup=button_markup, parse_mode='Markdown')

        time.sleep(250)  # duração dos sinais (300 segundos ou 5 minutos)

        bot.send_message(chat_id=chat_id, text=(f'''

✅️✅️✅️ 𝗚𝗥𝗘𝗘𝗡 ✅️✅️✅️

  '''), reply_markup=button_markup)

        #bot.send_sticker(chat_id, sticker='CAACAgEAAxkBAAEB_9tk2m8uHK6DbF9GulIeGDiA75d12QAC_AADOA6CEUCO7Z9DKY4HMAQ')

        time.sleep(60)
        ALERT_GALE1(link_cadastro, num_jogadas)
        time.sleep(10)
        DELETE_GALE1()
        time.sleep(50)
